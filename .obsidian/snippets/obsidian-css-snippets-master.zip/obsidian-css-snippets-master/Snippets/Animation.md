# Animations
```css
/* ===== snappier animations ==== */
.workspace-tab-header,
.workspace-tab-header-inner,
.workspace-tab-container-before,
.workspace-tab-container-after {
  transition: background-color 100ms linear;
}
```

# Hyphenation-Justification
```css
/* _hyphenation and justification      */
/*-------------------------------------*/
.cm-s-obsidian, .markdown-preview-view {
  text-align: justify;
  hyphens: auto;
}
```
